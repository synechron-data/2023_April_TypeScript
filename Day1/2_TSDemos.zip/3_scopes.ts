// Global
// Module Scope - Local to the file (Only if Module is enabled)
// Local Scope - Function Scoped
// Block Scope - Only if we use; let and const keyword

// var i = 20;
// var i = 30;
// console.log(i);

// var j = 20;
// // var j = "abc";          // Subsequent variable declarations must have the same type.
// console.log(j);

// -------------------------------------------  
// Supports Hoisting - Moving Declarations to the top

// a1 = "Hello";
// console.log(a1);
// var a1;

// -------------------------------------------  

// var i = 20;

// function test() {
//     var i = "Hello";            // Local (Function Scoped)
//     console.log("Inside Function, i is:", i);
// }

// test();
// console.log("Outside Function, i is:", i);

// -------------------------------------------  
// Using var keyword, you will get, either Global, Module or Function Scoping
// var does not support Block Scoping

// var i = 100;
// console.log("Before, i is", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// console.log("After, i is", i);

// ---------------------------------------------------------- let keyword

// We cannot create variables with same name in the same scope using let keyword
// let i = 20;
// let i = 30;                 // Cannot redeclare block-scoped variable 'i'
// console.log(i);

// -------------------------------------------  
// Does not Supports Hoisting

// a1 = "Hello";
// console.log(a1);
// let a1;

// -------------------------------------------  
// Support Block Scoping

var i = 100;
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);