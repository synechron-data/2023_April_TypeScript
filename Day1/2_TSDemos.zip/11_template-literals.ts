// var s1 = "Hello";
// var s2 = 'Hello';
// var s3 = `Hello`;

// console.log(s1);
// console.log(typeof s1);

// console.log(s2);
// console.log(typeof s2);

// console.log(s3);
// console.log(typeof s3);

// var s4 = "H\ne\nl\nl\no";
// console.log(s4);

// // Multiline strings
// var s5 = `H
// e
// l
// l
// o`;
// console.log(s5);

var fname = "Manish";
var lname = "Sharma";

var message1 = "Hello, " + fname + " " + lname;
console.log(message1);

var message2 = `Hello, ${fname} ${lname}`;
console.log(message2);