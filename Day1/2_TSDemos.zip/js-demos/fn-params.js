// function add(x, y) {
//     return x + y;
// }

// console.log(add(2, 3));
// console.log(add(2, "abc"));
// console.log(add("abc", "xyz"));
// console.log(add(2));
// console.log(add());
// console.log(add(2, 3, 4));

// function hello_js(name) {
//     console.log("Hello,", name);
// }

// hello_js("Manish");
// hello_js(10);
// hello_js();
// hello_js("Abhijeet", "Pune");
