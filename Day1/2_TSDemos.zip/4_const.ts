// let j: number;
// j = 10;
// j = 20;

// // const env: string;              // 'const' declarations must be initialized.

// const env = "development";
// console.log(env);

// // env = "production";                 // Cannot assign to 'env' because it is a constant.
// // console.log(env);

// if (true) {
//     const env = "production";
//     console.log("Block: ", env);
// }

// ------------------------------------------ Constant Objects
const obj = { id: 1 };
console.log(obj);

// obj = { name: "Manish" };                   // Cannot assign to 'obj' because it is a constant.

obj.id = 1000;
console.log(obj);

delete obj.id;
console.log(obj);
