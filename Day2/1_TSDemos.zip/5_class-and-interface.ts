// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// class Person implements IPerson {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 40);
// let p2: IPerson = new Person("Ramakant", 41);

// console.log(p1.greet("Hi"));
// console.log(p2.greet("Hi"));

// ------------------------------------------------- Multiple Interface Implementations
// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// class Person implements IPerson, IEmployee {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }
// }

// let p1: Person = new Person("Abhijeet", 40);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// // ------------------------------------------------- Interface Extraction
// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// interface ICustomer {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// // let p1: Person = new Person("Abhijeet", 40);
// // console.log(p1.greet("Hi"));
// // console.log(p1.doWork());
// // console.log(p1.doShopping());

// // Interface Extraction
// let p1: IPerson = new Person("Manish", 40);
// console.log(p1.greet("Hi"));

// let p2: IEmployee = new Person("Abhijeet", 40);
// console.log(p2.doWork());

// let p3: ICustomer = new Person("Ramakant", 40);
// console.log(p3.doShopping());

// ------------------------------------------------- Interface can extend other Interface(s)
// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee extends IPerson {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let us do it online";
//     }
// }

// let p1: IEmployee = new Person("Abhijeet", 40);
// console.log(p1.greet("Hola"));
// console.log(p1.doWork());

// let p2: ICustomer = new Person("Ramakant", 40);
// console.log(p2.greet("Hi"));
// console.log(p2.doShopping());

// ------------------------------------------------- Query (Dharam / Vishal)

// interface Utility {
//     method1: () => void;
//     method2?: () => void;
// }

// class UtilityType1 implements Utility {
//     method1(): void {
//         console.log("Hello from Method1");
//     }
// }

// class UtilityType2 implements Utility {
//     method1(): void {
//         console.log("Hello from Method1");
//     }

//     method2(): void {
//         console.log("Hello from Method2");
//     }

//     method3() {
//         console.log("Hello from Method3");
//     }
// }

// --------------------------------------------------------- Interface can extend from class(es)
// class Control {
//     get ControlId(): number {
//         return 10;
//     }

//     focus(): string {
//         return "The control is in focus....";
//     }
// }

// class SelectableControl {
//     select(): string {
//         return "the control is selected....";
//     }
// }

// // When an interface extends a class, it extends only the class members but not 
// // their implementation because interfaces don’t contain implementations.
// interface ISelectableControls extends Control, SelectableControl{}

// // Button Class have to re-implement all the methods
// class Button implements ISelectableControls{
//     get ControlId(): number {
//         throw new Error("Method not implemented.");
//     }
//     focus(): string {
//         throw new Error("Method not implemented.");
//     }
//     select(): string {
//         throw new Error("Method not implemented.");
//     }
// }

// ------------------------------------------------------------

// To create a user defined type
// Because no built in type supports the data you want o work with (Data Structure)

// class Cashier {
//     applyLoan() {

//     }
// }

// class BankManager {
//     approveLoan() {

//     }
// }

// class CashMan extends Cashier, BankManager {

// }

// var c1 = new CashMan();
// c1.applyLoan();
// c1.approveLoan();

// class Developer {
//     applyLeave() {

//     }
// }

// class PM {
//     approveLeave() {
        
//     }
// }

// class DevPM extends Developer, PM {

// }