// // TypeGuard Array
// var dataArr1: (number | string)[];
// dataArr1 = [1, "Manish"];
// dataArr1 = ["Abhijeet", 2];
// dataArr1 = ["Abhijeet", "Manish"];
// dataArr1 = [1, 2, 3, 4, 5];
// dataArr1 = [1, "Manish", "Pune", 411021];

// // Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence
let dataRow: [number, string];
dataRow = [1, "Manish"];
// dataRow = ["Abhijeet", 2];
// dataRow = ["Abhijeet", "Manish"];
// dataRow = [1, 2, 3, 4, 5];
// dataRow = [1, "Manish", "Pune", 411021];

console.log(dataRow[0]);
console.log(dataRow[1]);

for (const data of dataRow) {
    console.log(data);
}

// ---------------------------------------------

// function insert(data: (number|string)[]) {
//     // Code to insert the dat as row of a table
// }

function insert(data: [number, string]) {
    // Code to insert the dat as row of a table
}

insert([1, "Manish"]);
// insert(["Abhijeet", 2]);
// insert(["Abhijeet", "Manish"]);
// insert([1, "Manish", "Pune", 411021]);
// insert([1, 2, 3, 4, 5]);